package com.jibinghao.ztlibrary.entity;

/**
 * FileName: YearBean
 * Author: jibinghao
 * Date: 2019/5/13 10:22 AM
 * Email:heybinghao@gmail.com
 * Description:
 */

public class YearBean {
    public YearBean(String year) {
        this.year = year;
    }

    String year;

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }
}
